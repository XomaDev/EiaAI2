# What is this?

This is a standard library written in Eia64 👀

## How to use them?

It's simple!

````
stdlib(string, math..)
````